//package topicmodels.multithreads.UserEmbedding;
//
//import topicmodels.UserEmbedding.EUB;
//
///**
// * @author Lin Gong (lg5bt@virginia.edu)
// */
//public class EUB_multithreading extends EUB {
//
//}
