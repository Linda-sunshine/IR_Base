package structures;


public class _ParentDoc4ACCTMP extends _ParentDoc {

	double[] m_wordDistribution;

	public _ParentDoc4ACCTMP(int ID, String name, String title, String source,
			int ylabel) {
		super(ID, name, title, source, ylabel);


	}
	
	
}
