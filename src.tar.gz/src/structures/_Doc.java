/**
 * 
 */
package structures;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Random;

import utils.Utils;

/**
 * @author lingong
 * General structure to present a document for DM/ML/IR
 */
public class _Doc implements Comparable<_Doc> {
	String m_name;
	int m_ID; // unique id of the document in the collection
	String m_itemID; // ID of the product being commented
	String m_title; //The short title of the review.
	
	String m_source; //The content of the source file.
	int m_totalLength; //The total length of the document.
	
	int m_y_label; // classification target, that is the index of the labels.
	int m_predict_label; //The predicted result.
	double m_y_value; // regression target, like linear regression only has one value.	
	long m_timeStamp; //The timeStamp for this review.
	
	private _SparseFeature[] m_x_posVct;
	private double[] m_x_aspVct;
		
	//p(z|d) for topic models in general
	public double[] m_sentiment;
	
		
	//only used in learning to rank for random walk
	double m_weight = 1.0; // instance weight for supervised model training (will be reset by PageRank)
	double m_stopwordProportion = 0;
	double m_avgIDF = 0;
	double m_sentiScore = 0; //Sentiment score from sentiwordnet
	
	_Corpus m_corpus;
	
	public void setCorpus(_Corpus c)
	{
		m_corpus = c;
	}
	
	public double getAvgIDF() {
		return m_avgIDF;
	}

	public void setAvgIDF(double avgIDF) {
		this.m_avgIDF = avgIDF;
	}

	public double getStopwordProportion() {
		return m_stopwordProportion;
	}

	public void setStopwordProportion(double stopwordProportion) {
		this.m_stopwordProportion = stopwordProportion;
	}

	public void setSentiScore(double s){
		this.m_sentiScore = s;
	}

	//We only need one representation between dense vector and sparse vector: V-dimensional vector.
	private _SparseFeature[] m_x_sparse; // sparse representation of features: default value will be zero.
	private _SparseFeature[] m_x_projection; // selected features for similarity computation (NOTE: will use different indexing system!!)	
	
	static public final int stn_fv_size = 4; // cosine, length_ratio, position
	static public final int stn_senti_fv_size = 4; // cosine, sentiWordNetscore, prior_positive_negative_count
	
	_Stn[] m_sentences;
	
	//p(z|d) for topic models in general
	public double[] m_topics;
	//sufficient statistics for estimating p(z|d)
	public double[] m_sstat;//i.e., \gamma in variational inference p(\theta|\gamma)
	
	// structure only used by Gibbs sampling to speed up the sampling process
	public int[] m_words; 
	public int[] m_topicAssignment;
	
	// structure only used by variational inference
	public double[][] m_phi; // p(z|w, \phi)	
	Random m_rand;
	
	public double getSentiScore(){
		return this.m_sentiScore;
	}

	//Constructor.
	public _Doc (int ID, String source, int ylabel){
		this.m_ID = ID;
		this.m_source = source;
		this.m_y_label = ylabel;
		this.m_totalLength = 0;
		m_topics = null;
		m_sentiment = null;
		m_sstat = null;
		m_words = null;
		m_topicAssignment = null;
		m_sentences = null;
	}
	
	public _Doc (int ID, String source, int ylabel, long timeStamp){
		this.m_ID = ID;
		this.m_source = source;
		this.m_y_label = ylabel;
		this.m_totalLength = 0;
		this.m_timeStamp = timeStamp;
		m_topics = null;
		m_sentiment = null;
		m_sstat = null;
		m_words = null;
		m_topicAssignment = null;
		m_sentences = null;
	}
	
	public _Doc (int ID, String name, String source, String productID, int ylabel, long timeStamp){
		this.m_ID = ID;
		this.m_name = name;
		this.m_source = source;
		this.m_itemID = productID;
		this.m_y_label = ylabel;
		this.m_totalLength = 0;
		this.m_timeStamp = timeStamp;
		m_topics = null;
		m_sentiment = null;
		m_sstat = null;
		m_words = null;
		m_topicAssignment = null;
		m_sentences = null;
	}
	
	public _Doc (int ID, String name, String title, String source, String productID, int ylabel, long timeStamp){
		this.m_ID = ID;
		this.m_name = name;
		this.m_title = title;
		this.m_source = source;
		this.m_itemID = productID;
		this.m_y_label = ylabel;
		this.m_totalLength = 0;
		this.m_timeStamp = timeStamp;
		m_topics = null;
		m_sentiment = null;
		m_sstat = null;
		m_words = null;
		m_topicAssignment = null;
		m_sentences = null;
	}
	public void setWeight(double w) {
		m_weight = w;
	}
	
	public double getWeight() {
		return m_weight;
	}
	
	//Get the ID of the document.
	public int getID(){
		return this.m_ID;
	}
	
	//Set a new ID for the document.
	public int setID(int id){
		this.m_ID = id;
		return this.m_ID;
	}
	
	public void setItemID(String itemID) {
		m_itemID = itemID;
	}
	
	public String getItemID() {
		return m_itemID;
	}
	
	public void setName(String name) {
		m_name = name;
	}
	
	public String getName() {
		return m_name;
	}
	
	public String getTitle(){
		return m_title;
	}
	
	public double getTitleScore(){
		double score = 0;
		return score;
	}
	//Get the source content of a document.
	public String getSource(){
		return this.m_source;
	}
	
	//Get the real label of the doc.
	public int getYLabel() {
		return this.m_y_label;
	}
	
	//Set the Y value for the document, Y represents the class.
	public int setYLabel(int label){
		this.m_y_label = label;
		return this.m_y_label;
	}
	
	//Get the Y value, such as the result of linear regression.
	public double getYValue(){
		return this.m_y_value;
	}
	
	//Get the time stamp of the document.
	public long getTimeStamp(){
		return this.m_timeStamp;
	}
	
	//Set the time stamp for the document.
	public void setTimeStamp(long t){
		this.m_timeStamp = t;
	}
	
	//Get the sparse vector of the document.
	public _SparseFeature[] getSparse(){
		return this.m_x_sparse;
	}
	
	public _SparseFeature[] getProjectedFv() {
		return this.m_x_projection;
	}
	
	//return the unique number of features in the doc
	public int getDocLength() {
		return this.m_x_sparse.length;
	}	
	
	//Get the total number of tokens in a document.
	public int getTotalDocLength(){
		return this.m_totalLength;
	}
	
	void calcTotalLength() {
		m_totalLength = 0;
		for(_SparseFeature fv:m_x_sparse)
			m_totalLength += fv.getValue();
	}
	
	//Create the sparse vector for the document.
	public void createSpVct(HashMap<Integer, Double> spVct) {
		m_x_sparse = Utils.createSpVct(spVct);
		calcTotalLength();
	}
	
	//Create the sparse postagging vector for the document. 
	public void createPOSVct(HashMap<Integer, Double> posVct){
		m_x_posVct = Utils.createSpVct(posVct);
	}
	
	public _SparseFeature[] getPOSVct(){
		return m_x_posVct;
	}
	//Create the sparse vector for the document, taking value from different sections
	public void createSpVct(ArrayList<HashMap<Integer, Double>> spVcts) {
		m_x_sparse = Utils.createSpVct(spVcts);
		calcTotalLength();
	}
	
	public void setSpVct(_SparseFeature[] x) {
		m_x_sparse = x;
		calcTotalLength();
	}
	
	//Create a sparse vector with time features.
	public void createSpVctWithTime(LinkedList<_Doc> preDocs, int featureSize, double movingAvg, double norm){
		int featureLength = this.m_x_sparse.length;
		int timeLength = preDocs.size();
		_SparseFeature[] tempSparse = new _SparseFeature[featureLength + timeLength + 1];//to include the moving average
		System.arraycopy(m_x_sparse, 0, tempSparse, 0, featureLength);		
		int count = 0;
		for(_Doc doc:preDocs){
			double value = norm * doc.getYLabel();
			value *= Utils.calculateSimilarity(doc.getSparse(), m_x_sparse);//time-based features won't be considered since m_x_sparse does not contain time-based features yet
			tempSparse[featureLength + count] = new _SparseFeature(featureSize + count, value);
			count++;
		}	
		tempSparse[featureLength + count] = new _SparseFeature(featureSize + count, movingAvg*norm);
		this.m_x_sparse = tempSparse;
	}
	
	// added by Md. Mustafizur Rahman for HTMM Topic Modelling 
	public void setSentences(ArrayList<_SparseFeature[]> stnList) {
		m_sentences = new _Stn[stnList.size()];
		for(int i=0; i<m_sentences.length; i++)
			m_sentences[i] = new _Stn(stnList.get(i));
	}
	
	// added by Md. Mustafizur Rahman for HTMM Topic Modelling 
	public void setSentencesWithLabels(ArrayList<_SparseFeature[]> stnList, ArrayList<Integer> stnLabel) {
		m_sentences = new _Stn[stnList.size()];
		for(int i=0; i<m_sentences.length; i++)
			m_sentences[i] = new _Stn(stnList.get(i), stnLabel.get(i));
	}
	
	// added by Md. Mustafizur Rahman for HTMM Topic Modelling 
	public int getSenetenceSize() {
		return this.m_sentences.length;
	}
	
	public _Stn[] getSentences() {
		return m_sentences;
	}
	
	// added by Md. Mustafizur Rahman for HTMM Topic Modelling 
	public _Stn getSentence(int index) {
		return this.m_sentences[index];
	}
	
	//Get the predicted result, which is used for comparison.
	public int getPredictLabel() {
		return this.m_predict_label;
	}
	
	//Set the predict result back to the doc.
	public int setPredictLabel(int label){
		this.m_predict_label = label;
		return this.m_predict_label;
	}
	
	public boolean hasSegments() {
		return m_x_sparse[0].m_values != null;
	}
	
	public void setTopics(int k, double alpha) {
		if (m_topics==null || m_topics.length!=k) {
			m_topics = new double[k];
			m_sstat = new double[k];
		}
		Utils.randomize(m_sstat, alpha);
	}
	
	public double[] getTopics(){
		return m_topics;
	}
	//create necessary structure for variational inference
	public void setTopics4Variational(int k, double alpha) {
		if (m_topics==null || m_topics.length!=k) {
			m_topics = new double[k];
			m_sstat = new double[k];//used as p(z|w,\phi)
			m_phi = new double[m_x_sparse.length][k];
		}
		
		Arrays.fill(m_sstat, alpha);
		for(int n=0; n<m_x_sparse.length; n++) {
			Utils.randomize(m_phi[n], alpha);
			double v = m_x_sparse[n].getValue();
			for(int i=0; i<k; i++)
				m_sstat[i] += m_phi[n][i] * v;
		}
	}
	
	//create necessary structure to accelerate Gibbs sampling
	public void setTopics4Gibbs(int k, double alpha) {
		if (m_topics==null || m_topics.length!=k) {
			m_topics = new double[k];
			m_sstat = new double[k];
		}

		Arrays.fill(m_sstat, alpha);
		
		//Warning: in topic modeling, we cannot normalize the feature vector and we should only use TF as feature value!
		int docSize = (int)Utils.sumOfFeaturesL1(m_x_sparse);
		if (m_words==null || m_words.length != docSize) {
			m_topicAssignment = new int[docSize];
			m_words = new int[docSize];
		} 
		
		int wIndex = 0;
		if (m_rand==null)
			m_rand = new Random();
		for(_SparseFeature fv:m_x_sparse) {
			for(int j=0; j<fv.getValue(); j++) {
				m_words[wIndex] = fv.getIndex();
				m_topicAssignment[wIndex] = m_rand.nextInt(k); // randomly initializing the topics inside a document
				m_sstat[m_topicAssignment[wIndex]] ++; // collect the topic proportion
				
				wIndex ++;
			}
		}
	}
	
	//permutation the order of words for Gibbs sampling
	public void permutation() {
		int s, t;
		for(int i=m_words.length-1; i>1; i--) {
			s = m_rand.nextInt(i);
			
			//swap the word
			t = m_words[s];
			m_words[s] = m_words[i];
			m_words[i] = t;
			
			//swap the topic assignment
			t = m_topicAssignment[s];
			m_topicAssignment[s] = m_topicAssignment[i];
			m_topicAssignment[i] = t;
		}
	}
		
	// used by LR-HTSM for constructing transition features for sentiment
	public void setSentenceFeatureVectorForSentiment() {
		// start from 2nd sentence
		double pSim = Utils.cosine(m_sentences[0].getFv(), m_sentences[1].getFv()), nSim;
		double pSenscore = sentiWordScore(0), cSenscore;
		int pposneg=posnegcount(0),cposneg;
		
		int stnSize = getSenetenceSize();
		for(int i=1; i<stnSize; i++){
			//cosine similarity			
			m_sentences[i-1].m_sentitransitFv[0] = pSim;			
			
			//sentiWordScore
			cSenscore = sentiWordScore(i);
			if((cSenscore<0 && pSenscore>0) || (cSenscore>0 && pSenscore<0))
				m_sentences[i-1].m_sentitransitFv[1] = 1; // transition
			else if((cSenscore<=0 && pSenscore<=0) || (cSenscore>=0 && pSenscore>=0))
				m_sentences[i-1].m_sentitransitFv[1] = -1; // no transition
			pSenscore = cSenscore;
			
			//positive negative count 
			cposneg = posnegcount(i);
			if(pposneg==cposneg)
				m_sentences[i-1].m_sentitransitFv[2] = -1; // no transition
			else if (pposneg!=cposneg)
				m_sentences[i-1].m_sentitransitFv[2] = 1; // transition
			pposneg = cposneg;
			
			//similar to previous or next
			if (i<stnSize-1) {
				nSim = Utils.cosine(m_sentences[i].getFv(), m_sentences[i+1].getFv());
				if (nSim>pSim)
					m_sentences[i-1].m_sentitransitFv[3] = 1;
				else if (nSim<pSim)
					m_sentences[i-1].m_sentitransitFv[3] = -1;
				pSim = nSim;
			}
		}
	}
	
	// receive sentence index as parameter
	public double sentiWordScore(int i)
	{
		_SparseFeature[] wordsinsentence = m_sentences[i].getFv();
		int index;
		String token;
		double senscore = 0.0;
		double tmp;
		
		for(_SparseFeature word:wordsinsentence){
			index = word.getIndex();
			token = m_corpus.m_features.get(index);
			tmp = m_corpus.sentiwordnet.extract(token, "n");
			if(tmp!=-2) // word found in SentiWordNet
				senscore+=tmp;
		}
		return senscore;
	}
	
	// receive sentence index as parameter
	public int posnegcount(int i)
	{
		_SparseFeature[] wordsinsentence = m_sentences[i].getFv();
		int index;
		String token;
		int poscount = 0;
		int negcount = 0;
		
		for(_SparseFeature word:wordsinsentence){
			index = word.getIndex();
			token = m_corpus.m_features.get(index);
			if(m_corpus.m_pospriorlist.contains(token))
				poscount++;
			else if(m_corpus.m_negpriorlist.contains(token))
				negcount++;
		}
		
		if(poscount>negcount)
			return 1; // 1 means sentence is more positive
		else if (negcount>poscount)
			return 2; // 2 means sentence is more negative
		else
			return 0; // sentence is neutral or no match
	}
	
	
	// used by LR-HTMM for constructing transition features
	public void setSentenceFeatureVector() {
		// start from 2nd sentence
		double cLength, pLength = Utils.sumOfFeaturesL1(m_sentences[0].getFv());
		double pSim = Utils.cosine(m_sentences[0].getFv(), m_sentences[1].getFv()), nSim;
		int stnSize = getSenetenceSize();
		for(int i=1; i<stnSize; i++){
			//cosine similarity			
			m_sentences[i-1].m_transitFv[0] = pSim;			

			cLength = Utils.sumOfFeaturesL1(m_sentences[i].getFv());
			//length_ratio
			m_sentences[i-1].m_transitFv[1] = (pLength-cLength)/Math.max(cLength, pLength);
			pLength = cLength;

			//position
			m_sentences[i-1].m_transitFv[2] = (double)i / stnSize;

			//similar to previous or next
			if (i<stnSize-1) {
				nSim = Utils.cosine(m_sentences[i].getFv(), m_sentences[i+1].getFv());
				if (nSim>pSim)
					m_sentences[i-1].m_transitFv[3] = 1;
				else if (nSim<pSim)
					m_sentences[i-1].m_transitFv[3] = -1;
				pSim = nSim;
			}
		}
	}

	
	public void clearSource() {
		m_source = null;
	}

	@Override
	public int compareTo(_Doc d) {
		int prodCompare = m_itemID.compareTo(d.m_itemID);
		if (prodCompare==0) {
			if(m_timeStamp == d.getTimeStamp())
				return 0;
			return m_timeStamp < d.getTimeStamp() ? -1 : 1;
		} else
			return prodCompare;
	}
	
	public boolean sameProduct(_Doc d) {
		if (m_itemID == null || d.m_itemID == null)
			return false;
		return m_itemID.equals(d.m_itemID);
	}
	
	@Override
	public String toString() {
		return String.format("ProdID: %s\tID: %s\t Rating: %d\n%s", m_itemID, m_name, m_y_label, m_source);
	}
	
	public void setProjectedFv(Map<Integer, Integer> filter) {
		m_x_projection = Utils.projectSpVct(m_x_sparse, filter);
//		if (m_x_projection!=null)
//			Utils.L2Normalization(m_x_projection);
	}

	public void setAspVct(double[] aspVct){
		m_x_aspVct = aspVct;
	}
	
	public double[] getAspVct(){
		return m_x_aspVct;
	}
	
	public void setSentiment(double[] senti, int k){
		if(senti.length == k){
			m_sentiment = senti;
		}
	}
	
	public void setProjectedFv(double[] denseFv) {
		m_x_projection = Utils.createSpVct(denseFv);
	}
}
