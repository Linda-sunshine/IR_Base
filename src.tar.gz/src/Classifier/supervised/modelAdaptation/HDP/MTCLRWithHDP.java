package Classifier.supervised.modelAdaptation.HDP;

import java.util.HashMap;

import Classifier.supervised.modelAdaptation.DirichletProcess.MTCLRWithDP;

public class MTCLRWithHDP extends MTCLRWithDP{

	public MTCLRWithHDP(int classNo, int featureSize,
			HashMap<String, Integer> featureMap, String globalModel) {
		super(classNo, featureSize, featureMap, globalModel);
		// TODO Auto-generated constructor stub
	}

}
