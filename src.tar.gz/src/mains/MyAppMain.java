package mains;

public class MyAppMain {
	public static void main(String[] args){
		String model = "./data/models/";
		
		
	}

}
